// POST /api/plan-trip
// Body: { destinationId, dates, extra? }
// Calls Claude (if ANTHROPIC_API_KEY is set) to generate a tailored
// itinerary for the chosen destination, respecting the family profile and
// excluding already-visited places.

const { sendJson, readJsonBody } = require("../lib/http.js");
const store = require("../lib/store.js");
const destinations = require("../data/destinations.js");
const profile = require("../data/profile.js");
const { planTrip, isAiConfigured } = require("../lib/ai.js");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return sendJson(res, 405, { error: "Method not allowed" });
  }
  if (!isAiConfigured()) {
    return sendJson(res, 501, {
      error: "ANTHROPIC_API_KEY is not configured on this deployment. Add it in your Vercel project's Environment Variables to enable AI itinerary planning.",
    });
  }
  try {
    const body = await readJsonBody(req);
    const destination = destinations.find((d) => d.id === body.destinationId);
    if (!destination) return sendJson(res, 400, { error: "Unknown destinationId" });

    const visitedPlaces = await store.getVisitedPlaces();
    const itinerary = await planTrip({
      profile,
      destination,
      visitedPlaces,
      dates: body.dates || "your chosen dates",
      extra: body.extra || "",
    });
    sendJson(res, 200, { itinerary });
  } catch (err) {
    sendJson(res, 500, { error: String(err.message || err) });
  }
};
