// POST /api/chat { destinationId, messages: [{ role: "user"|"assistant", content }] }
// -> { reply }
//
// Stateless — the client keeps the running conversation and resends the
// whole thing each turn. Needs ANTHROPIC_API_KEY, same as plan-trip.js.

const { sendJson, readJsonBody } = require("../lib/http.js");
const store = require("../lib/store.js");
const destinations = require("../data/destinations.js");
const { chatAboutTrip, isAiConfigured } = require("../lib/ai.js");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return sendJson(res, 405, { error: "Method not allowed" });
  }
  if (!isAiConfigured()) {
    return sendJson(res, 501, { error: "ANTHROPIC_API_KEY isn't configured, so AI chat isn't available yet." });
  }
  const body = await readJsonBody(req);
  const destination = destinations.find((d) => d.id === body.destinationId);
  if (!destination) return sendJson(res, 400, { error: "Unknown destinationId" });

  try {
    const [profile, visitedPlaces] = await Promise.all([store.getProfile(), store.getVisitedPlaces()]);
    const reply = await chatAboutTrip({ profile, destination, visitedPlaces, messages: body.messages });
    sendJson(res, 200, { reply });
  } catch (err) {
    sendJson(res, 500, { error: String(err.message || err) });
  }
};
