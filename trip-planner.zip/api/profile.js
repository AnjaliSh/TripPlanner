// GET  /api/profile                                  -> { profile }
// POST /api/profile { action: "addPoint", sectionId, text }     -> { profile }
// POST /api/profile { action: "removePoint", sectionId, index } -> { profile }
//
// The profile is now editable and persisted (same Upstash/local-file
// pattern as visited places), seeded from data/profile.js the first time
// it's read. That file stays as the source-of-truth default, but day-to-day
// edits (including AI-extracted preferences from api/extract-preferences.js)
// go through here instead.

const { sendJson, readJsonBody } = require("../lib/http.js");
const store = require("../lib/store.js");

module.exports = async function handler(req, res) {
  if (req.method === "GET") {
    const profile = await store.getProfile();
    return sendJson(res, 200, { profile });
  }

  if (req.method === "POST") {
    const body = await readJsonBody(req);
    try {
      let profile;
      if (body.action === "addPoint") {
        profile = await store.addProfilePoint(body.sectionId, body.text);
      } else if (body.action === "removePoint") {
        profile = await store.removeProfilePoint(body.sectionId, body.index);
      } else {
        return sendJson(res, 400, { error: "Unknown action" });
      }
      return sendJson(res, 200, { profile });
    } catch (err) {
      return sendJson(res, 400, { error: String(err.message || err) });
    }
  }

  return sendJson(res, 405, { error: "Method not allowed" });
};
