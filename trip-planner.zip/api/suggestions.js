// GET /api/suggestions
// Returns the curated destination shortlist, with already-visited places
// filtered out (based on the visited-places store).

const { sendJson } = require("../lib/http.js");
const store = require("../lib/store.js");
const destinations = require("../data/destinations.js");
const { buildTravelLinks } = require("../lib/travelLinks.js");
const { scoreDestination } = require("../lib/matchScore.js");
const { getLandmarkImages } = require("../lib/wikiImage.js");

module.exports = async function handler(req, res) {
  if (req.method !== "GET") {
    return sendJson(res, 405, { error: "Method not allowed" });
  }
  try {
    const visited = await store.getVisitedPlaces();
    const shortlisted = destinations.filter((d) => !store.isPlaceVisited(d, visited));
    const images = await getLandmarkImages(shortlisted.map((d) => d.landmarkQuery));
    const suggestions = shortlisted
      .map((d) => ({
        ...d,
        links: buildTravelLinks(d),
        match: scoreDestination(d),
        image: images[d.landmarkQuery] || null,
      }))
      .sort((a, b) => b.match.score - a.match.score);
    const hidden = destinations.length - suggestions.length;
    sendJson(res, 200, { suggestions, hiddenCount: hidden });
  } catch (err) {
    sendJson(res, 500, { error: String(err.message || err) });
  }
};
