# Family Trip Planner

A small, (almost) dependency-free web app for planning family trips from London:

- **Long Weekend Radar** — pulls live UK bank holiday dates from gov.uk and shows every upcoming long weekend, with a countdown to when its ~3-month planning window opens.
- **Suggestions** — a curated shortlist of toddler-friendly, warm-and-welcoming destinations, ranked by a transparent **profile-fit score** (e.g. "5/6") based on real keywords in the curated notes — not an invented percentage. Cards show a real photo of the destination's landmark as a dimmed background (pulled live from Wikipedia, no key needed — see `landmarkQuery` in `data/destinations.js` if you want to change which landmark). Click "View details" on any card for a full breakdown, hero photo, live weather norms, and which specific criteria it does/doesn't clear. Automatically hides anywhere already in your visited-places list.
- **Map** — every remaining suggestion plotted on a map from London, via Leaflet + OpenStreetMap (no API key needed), with a landmark photo thumbnail in each pin's popup.
- **AI chat customization** — inside a destination's detail view, "💬 Customize with AI chat" opens a real back-and-forth conversation about that specific trip (swap a day, ask about a specific park, adjust pacing) — grounded in your profile and that destination's notes. Needs `ANTHROPIC_API_KEY`. Conversation lives in the browser only (nothing saved server-side), so it resets if you leave the detail view or reload.
- **Find real stays** — click "Find real stays" on any destination card for actual aparthotel/serviced-apartment listings with names, ratings and photos (via Google Places), plus one-click links into live Booking.com and Airbnb searches. Works without a Google Maps key too — you just get the search links instead of inline results.
- **Visited Places** — add/remove places you've already been, with a quick 🟢/🟡/🔴 rating chip. Shown as passport-stamp cards. Suggestions update instantly.
- **Notes → Profile** — write a free-text note on a visited place and hit "✨ Process & extract preferences" — Claude reads it and proposes specific additions to your travel profile (e.g. "prefers large conventional ferries"), which you accept or skip individually. Needs `ANTHROPIC_API_KEY`.
- **Plan with AI** — pick a destination and dates, and Claude generates a day-by-day itinerary, accommodation leads, budget range, and dining picks tailored to your exact profile (needs your own Anthropic API key). Also surfaces live flight/hotel search links for those exact dates.
- **Travel Profile** — now editable in the app itself (add/remove preference bullets per section), not just in `data/profile.js`. Edits persist the same way visited places do.
- **Weekly nudge** — a cron job checks for long weekends entering the 3-month window and emails you a shortlist (needs Vercel + a free Resend account).
- **Mobile-first nav** — the tab bar becomes a sticky bottom bar with icons on small screens.

> **No access control right now.** An earlier version of this had a password gate in front of every API route; it's been pulled out for now to keep local testing simple. That means once this is deployed to a public Vercel URL, anyone with the link can read/edit your data and spend your Anthropic API budget. Worth revisiting before a real deploy — flag it and we can add a simpler version back in.

No frameworks, no build step. The only non-npm dependency is Leaflet, loaded from a CDN in the browser for the Map tab — there's still nothing to `npm install` to run this locally.

## Run it locally

```bash
npm install   # installs nothing right now — just here so `npm run dev` works
npm run dev
```

Open http://localhost:3000. Visited places are stored in `data/visited-places.local.json` until you connect Upstash Redis (see below).

## Deploy to Vercel

1. Push this folder to a GitHub repo.
2. In Vercel: **New Project → Import** your repo. No framework preset needed — Vercel will detect the `/api` functions and serve `/public` automatically. No build command required.
3. Add environment variables under **Project → Settings → Environment Variables**:

   | Variable | Required for | Notes |
   |---|---|---|
   | `UPSTASH_REDIS_REST_URL` | Persisting visited places online | Free tier at [upstash.com](https://upstash.com) → create a Redis database → copy the REST URL |
   | `UPSTASH_REDIS_REST_TOKEN` | Persisting visited places online | Same Upstash database → REST token |
   | `ANTHROPIC_API_KEY` | "Plan with AI" tab + AI chat customization + notes→profile extraction | Your own key from [console.anthropic.com](https://console.anthropic.com) |
   | `GOOGLE_MAPS_API_KEY` | Real accommodation listings in "Find real stays" | Free tier ($200/mo credit) at [console.cloud.google.com](https://console.cloud.google.com) — enable the **Places API (New)**. Without this, "Find real stays" still gives you live Booking.com/Airbnb search links, just no inline results. |
   | `RESEND_API_KEY` | Weekly email nudge | Free tier at [resend.com](https://resend.com) |
   | `RESEND_FROM` | Weekly email nudge | e.g. `Trip Planner <planner@yourdomain.com>` — Resend requires a verified sending domain, or use their shared test domain while you set this up |
   | `RESEND_TO` | Weekly email nudge | Your inbox |
   | `CRON_SECRET` | Optional hardening | If set, only Vercel Cron's authenticated request can trigger `/api/cron/weekly-check` |

   Landmark photos need no env var at all — they come from Wikipedia's public API, which is keyless.

4. Deploy. The cron in `vercel.json` runs daily at 08:00 UTC and hits `/api/cron/weekly-check` — it only actually sends an email on the (rare) day a long weekend's 3-month window has just opened, so a daily check is what keeps it from being missed.

**Without Upstash configured**, visited places will reset on every deploy (Vercel's filesystem is read-only/ephemeral in production) — so for a real deployment, set up Upstash Redis (takes ~2 minutes, free tier is plenty for one user).

**Without Resend configured**, the weekly cron still runs and returns what it *would* have sent (visit `/api/cron/weekly-check` directly to check), it just won't email you.

**Without an Anthropic key**, every tab works except "Plan with AI", which will show a clear message instead of erroring.

**Without a Google Maps key**, "Find real stays" falls back to the curated accommodation notes plus live Booking.com/Airbnb search links — still useful, just not inline photos/ratings.

## Project structure

```
api/                    Serverless functions (also used directly by the local dev server)
  long-weekends.js       GET  - computed long weekends + countdowns
  visited-places.js      GET/POST/DELETE - visited places CRUD (rating included)
  suggestions.js          GET  - curated destinations + match score + landmark photo + live flight links, filtered by visited places
  accommodations.js        GET  - live Google Places results (or fallback links) for a destination
  plan-trip.js               POST - AI itinerary generation
  profile.js                   GET/POST - your travel profile, now editable
  extract-preferences.js         POST - reads a visited-place note, proposes profile additions
  chat.js                          POST - AI chat customization for a specific destination
  cron/weekly-check.js               GET  - the 3-month-ahead email nudge, hit by Vercel Cron
data/
  destinations.js         Curated destination shortlist — coordinates, airport codes, typical weather, landmark photo query
  profile.js                 Seed/default travel profile (source of truth on first run; edits after that live in storage, same as visited places)
  bankHolidaysFallback.js     Snapshot used only if the live gov.uk fetch fails
  visited-places.local.json     Local dev fallback store (seeded with Bilbao & Plentzia)
  profile.local.json               Local dev fallback store for profile edits (auto-created, gitignored)
lib/
  bankHolidays.js          Long-weekend calculation logic
  store.js                   Visited-places + profile storage (Upstash in prod, local files in dev)
  ai.js                        Claude API calls: itinerary generation, notes-to-profile extraction, chat
  places.js                      Google Places API call for live accommodation search
  wikiImage.js                     Live landmark photo lookup via Wikipedia's free REST API
  matchScore.js                      Transparent profile-fit scoring — see the source for the exact criteria
  travelLinks.js                       Builds Google Flights/Skyscanner/Booking.com/Airbnb deep links
  email.js                               Resend API call for the nudge email
  http.js                                  Tiny JSON helpers shared by every API handler
public/                  Static frontend — plain HTML/CSS/JS, no build step (Leaflet via CDN for the map)
server.js                Zero-dependency local dev server
vercel.json              Cron schedule config
```

## Extending it

- **Add destinations**: edit `data/destinations.js` — each entry needs `coordinates: {lat, lng}` and `airportCode` now (used by the map and flight links), alongside the existing fields.
- **Update your travel profile**: edit `data/profile.js`. This feeds both the Profile tab and the AI itinerary prompt.
- **Log a visited place**: use the Visited Places tab in the app (or `POST /api/visited-places`).
- **Change the reminder cadence**: edit the `schedule` in `vercel.json` (cron syntax). Note Vercel's free Hobby plan runs cron jobs at most once a day.

## A note on the seeded visited places

`Bilbao` and `Plentzia` were pre-added to the visited list based on how you described them ("our amazing experience in Bilbao", the Kate Gorantz mention in Plentzia). Double-check these are right, and add anywhere else you've already been (Athens? Naxos?) via the Visited Places tab so suggestions stay accurate.
