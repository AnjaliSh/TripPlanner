// public/app.js — vanilla JS, no build step, no dependencies (Leaflet is
// the one exception, loaded via <script> tag in index.html for the map tab).

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

async function api(path, options) {
  const res = await fetch(`/api/${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `Request failed (${res.status})`);
  return json;
}

// ---------- Tabs ----------
let mapInstance = null;

$$("nav.tabs button").forEach((btn) => {
  btn.addEventListener("click", () => {
    $$("nav.tabs button").forEach((b) => b.classList.remove("active"));
    $$("section.panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    $(`#${btn.dataset.tab}`).classList.add("active");
    if (btn.dataset.tab === "map" && mapInstance) {
      // Leaflet needs a nudge after being unhidden, or it renders at 0x0.
      setTimeout(() => mapInstance.invalidateSize(), 50);
    }
  });
});

// ---------- Long Weekend Radar ----------
async function loadRadar() {
  const el = $("#radar-list");
  try {
    const { longWeekends } = await api("long-weekends");
    if (longWeekends.length === 0) {
      el.innerHTML = `<p class="muted">No long weekends found in the next 18 months.</p>`;
      return;
    }
    el.innerHTML = longWeekends
      .map((lw) => {
        const hot = lw.windowIsOpenNow;
        const statusPill = hot
          ? `<span class="pill warn">Window open now</span>`
          : lw.daysUntilWindowOpens > 0
          ? `<span class="pill">Opens in ${lw.daysUntilWindowOpens}d</span>`
          : `<span class="pill">Trip passed</span>`;
        return `
          <div class="ticket ${hot ? "hot" : ""}">
            <div class="ticket-body">
              <h3>${lw.label}</h3>
              <p class="ticket-dates">${lw.startDate} → ${lw.endDate} · ${lw.lengthDays} days</p>
              ${statusPill}
              <p class="muted" style="margin-top:8px;">Planning window opens ${lw.planningWindowOpens}</p>
            </div>
            <div class="ticket-stub">in<br/>${lw.daysUntilTrip}d</div>
          </div>`;
      })
      .join("");
  } catch (err) {
    el.innerHTML = `<div class="error-banner">Couldn't load long weekends: ${err.message}</div>`;
  }
}

// ---------- Suggestions ----------
let lastSuggestions = [];

function matchBadgeClass(match) {
  const ratio = match.score / match.total;
  if (ratio >= 0.8) return "";
  if (ratio >= 0.5) return "partial";
  return "low";
}

async function loadSuggestions() {
  const el = $("#suggestions-list");
  const meta = $("#suggestions-meta");
  try {
    const { suggestions, hiddenCount } = await api("suggestions");
    lastSuggestions = suggestions;
    meta.textContent = hiddenCount > 0
      ? `Showing ${suggestions.length} destinations, best fit first · ${hiddenCount} hidden because they're in your visited list.`
      : `Showing ${suggestions.length} destinations, best fit first.`;
    el.innerHTML = suggestions
      .map((d) => {
        const bgStyle = d.image
          ? `style="background-image: linear-gradient(180deg, rgba(15,23,32,0.45) 0%, rgba(15,23,32,0.75) 55%, rgba(15,23,32,0.88) 100%), url('${d.image.imageUrl}')"`
          : "";
        return `
        <div class="dest-card ${d.image ? "has-photo" : ""}" data-id="${d.id}" ${bgStyle}>
          <div class="dest-head">
            <h3>${d.name}, ${d.country}</h3>
            <span class="dest-code">${d.airportCode}</span>
          </div>
          <div class="dest-body">
            <span class="match-badge ${matchBadgeClass(d.match)}">${d.match.score}/${d.match.total} profile fit</span>
            <p class="muted">${d.flightTimeFromLondon} flight · ${d.budgetTier} · best ${d.bestSeasons.join(", ")}</p>
            <p class="weather-line">🌤️ ${d.typicalWeather}</p>
            <div>${d.vibeTags.map((t) => `<span class="tag">${t}</span>`).join("")}</div>
            <p>${d.whyProfile}</p>
            <div class="dest-actions">
              <a class="btn-link" href="${d.links.flights.googleFlights}" target="_blank" rel="noopener">Check flights ↗</a>
              <button class="btn-link" data-find-stays="${d.id}">Find real stays</button>
              <button class="btn-link" data-view-detail="${d.id}">View details →</button>
            </div>
            <div class="stay-results" id="stays-${d.id}" hidden></div>
          </div>
          ${d.image ? `<div class="photo-credit">📷 ${d.landmarkQuery}, via Wikipedia</div>` : ""}
        </div>`;
      })
      .join("");
    populatePlanDestinationSelect(suggestions);
    $$("#suggestions-list [data-find-stays]").forEach((btn) => {
      btn.addEventListener("click", () => loadStaysInto(btn.dataset.findStays, btn));
    });
    $$("#suggestions-list [data-view-detail]").forEach((btn) => {
      btn.addEventListener("click", () => showDestinationDetail(btn.dataset.viewDetail));
    });
    verifyCardPhotosLoaded(suggestions);
  } catch (err) {
    el.innerHTML = `<div class="error-banner">Couldn't load suggestions: ${err.message}</div>`;
  }
}

/**
 * The background-image is already set inline, but CSS background-image
 * failures are silent (no error event to hook). This preloads each photo
 * via a real <img> so a broken/blocked URL logs clearly in the console
 * instead of just quietly showing an empty dark card.
 */
function verifyCardPhotosLoaded(suggestions) {
  suggestions.forEach((d) => {
    if (!d.image) return;
    const probe = new Image();
    probe.onerror = () => {
      console.warn(`[trip-planner] landmark photo failed to load for "${d.name}" (${d.landmarkQuery}): ${d.image.imageUrl}`);
      const card = $(`.dest-card[data-id="${d.id}"]`);
      if (card) card.style.backgroundImage = "linear-gradient(160deg, var(--airmail-blue), var(--ink))";
    };
    probe.src = d.image.imageUrl;
  });
}

function showDestinationDetail(destinationId) {
  const d = lastSuggestions.find((s) => s.id === destinationId);
  if (!d) return;
  $("#suggestions-list").hidden = true;
  $("#suggestions-meta").hidden = true;
  const detail = $("#suggestions-detail");
  detail.hidden = false;
  const criteriaHtml = [
    ...d.match.matched.map((label) => `<span class="criterion-pill yes">✓ ${label}</span>`),
    ...d.match.unmatched.map((label) => `<span class="criterion-pill no">${label}</span>`),
  ].join("");
  const heroStyle = d.image
    ? `style="background-image: linear-gradient(180deg, rgba(15,23,32,0.25) 0%, rgba(15,23,32,0.85) 100%), url('${d.image.imageUrl}')"`
    : "";
  detail.innerHTML = `
    <div class="detail-hero ${d.image ? "" : "no-photo"}" ${heroStyle}>
      <button class="btn-link back-btn" id="detail-back">← Back to all suggestions</button>
      <h2>${d.name}, ${d.country}</h2>
      <span class="match-badge ${matchBadgeClass(d.match)}">${d.match.score}/${d.match.total} profile fit</span>
    </div>
    <div class="detail-body">
      <div class="detail-stats">
        <div class="stat"><div class="stat-label">Flight</div><div class="stat-value">${d.flightTimeFromLondon} from LON (${d.airportCode})</div></div>
        <div class="stat"><div class="stat-label">Budget</div><div class="stat-value">${d.budgetTier}</div></div>
        <div class="stat"><div class="stat-label">Weather</div><div class="stat-value">${d.typicalWeather}</div></div>
        <div class="stat"><div class="stat-label">Best seasons</div><div class="stat-value">${d.bestSeasons.join(", ")}</div></div>
      </div>
      <div class="section-title">Why it fits your profile</div>
      <div class="detail-criteria">${criteriaHtml}</div>
      <p>${d.whyProfile}</p>
      <div class="section-title">Notes</div>
      <p class="muted"><strong>Stay:</strong> ${d.accommodationNotes}</p>
      <p class="muted"><strong>Veg food:</strong> ${d.vegFoodNotes}</p>
      <p class="muted"><strong>Kids:</strong> ${d.kidNotes}</p>
      <p class="muted"><strong>Airport/logistics:</strong> ${d.airportNotes || "—"}</p>
      <div class="dest-actions" style="margin-top:10px;">
        <a class="btn-link" href="${d.links.flights.googleFlights}" target="_blank" rel="noopener">Check flights ↗</a>
        <a class="btn-link" href="${d.links.flights.skyscanner}" target="_blank" rel="noopener">Skyscanner ↗</a>
        <button class="btn-link" data-find-stays="${d.id}">Find real stays</button>
        <button class="btn-link" id="chat-toggle">💬 Customize with AI chat</button>
      </div>
      <div class="stay-results" id="stays-${d.id}" hidden></div>
      <div id="chat-panel"></div>
    </div>
  `;
  $("#detail-back").addEventListener("click", closeDestinationDetail);
  $(`#suggestions-detail [data-find-stays]`).addEventListener("click", (e) => loadStaysInto(d.id, e.target));
  $("#chat-toggle").addEventListener("click", () => openChatPanel(d));
}

function closeDestinationDetail() {
  $("#suggestions-detail").hidden = true;
  $("#suggestions-list").hidden = false;
  $("#suggestions-meta").hidden = false;
  chatMessages = [];
  chatDestination = null;
}

// ---------- AI chat customization ----------
let chatMessages = [];
let chatDestination = null;

function renderChatBubbles() {
  const container = $("#chat-messages");
  if (!container) return;
  container.innerHTML = chatMessages
    .map((m) => `<div class="chat-bubble ${m.role}">${m.content.replace(/</g, "&lt;")}</div>`)
    .join("");
  container.scrollTop = container.scrollHeight;
}

function openChatPanel(destination) {
  chatDestination = destination;
  if (chatMessages.length === 0) {
    chatMessages = [
      { role: "assistant", content: `Ask me anything about tailoring a trip to ${destination.name} — swap a day, ask about a specific park, adjust the pace, whatever's on your mind.` },
    ];
  }
  const panel = $("#chat-panel");
  panel.innerHTML = `
    <div class="chat-panel">
      <div class="chat-messages" id="chat-messages"></div>
      <div class="chat-input-row">
        <input type="text" id="chat-input" placeholder="Ask about ${destination.name}…" />
        <button class="primary" id="chat-send">Send</button>
      </div>
    </div>`;
  renderChatBubbles();
  $("#chat-send").addEventListener("click", sendChatMessage);
  $("#chat-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendChatMessage();
  });
  $("#chat-toggle").hidden = true;
}

async function sendChatMessage() {
  const input = $("#chat-input");
  const text = input.value.trim();
  if (!text || !chatDestination) return;
  input.value = "";
  chatMessages.push({ role: "user", content: text });
  renderChatBubbles();
  const sendBtn = $("#chat-send");
  sendBtn.disabled = true;
  try {
    const { reply } = await api("chat", {
      method: "POST",
      body: JSON.stringify({ destinationId: chatDestination.id, messages: chatMessages }),
    });
    chatMessages.push({ role: "assistant", content: reply });
    renderChatBubbles();
  } catch (err) {
    chatMessages.push({ role: "assistant", content: `(couldn't reply: ${err.message})` });
    renderChatBubbles();
  } finally {
    sendBtn.disabled = false;
  }
}

async function loadStaysInto(destinationId, triggerBtn) {
  const out = $(`#stays-${destinationId}`);
  out.hidden = false;
  out.innerHTML = `<p class="muted">Searching for real places to stay…</p>`;
  if (triggerBtn) triggerBtn.disabled = true;
  try {
    const { listings, curatedNotes, links, source } = await api(`accommodations?destinationId=${encodeURIComponent(destinationId)}`);
    let html = "";
    if (listings.length > 0) {
      html += listings
        .map(
          (l) => `
        <div class="stay-listing">
          ${l.photoUrl ? `<img src="${l.photoUrl}" alt="" loading="lazy" />` : `<div style="width:64px;height:64px;border-radius:8px;background:var(--chart);flex-shrink:0;"></div>`}
          <div class="stay-meta">
            <div class="name">${l.name}${l.rating ? ` · ★ ${l.rating} (${l.ratingCount})` : ""}</div>
            <div class="muted">${l.address}</div>
            ${l.mapsUrl ? `<a class="btn-link" style="margin-top:4px;" href="${l.mapsUrl}" target="_blank" rel="noopener">View on Maps ↗</a>` : ""}
          </div>
        </div>`
        )
        .join("");
    } else {
      html += `<p class="muted">${source === "curated-notes-only" ? "Live search isn't configured (no GOOGLE_MAPS_API_KEY) — here's what's already known:" : "No live results — here's what's already known:"} ${curatedNotes}</p>`;
    }
    html += `<div class="dest-actions" style="margin-top:8px;">
      <a class="btn-link" href="${links.accommodation.booking}" target="_blank" rel="noopener">Search Booking.com ↗</a>
      <a class="btn-link" href="${links.accommodation.airbnb}" target="_blank" rel="noopener">Search Airbnb ↗</a>
    </div>`;
    out.innerHTML = html;
  } catch (err) {
    out.innerHTML = `<div class="error-banner">Couldn't load stays: ${err.message}</div>`;
  } finally {
    if (triggerBtn) triggerBtn.disabled = false;
  }
}

function populatePlanDestinationSelect(suggestions) {
  const sel = $("#plan-destination");
  sel.innerHTML = suggestions.map((d) => `<option value="${d.id}">${d.name}, ${d.country}</option>`).join("");
}

// ---------- Map ----------
function initMap(suggestions) {
  if (!window.L) return;
  const canvas = $("#map-canvas");
  if (!canvas || mapInstance) return;

  mapInstance = L.map(canvas).setView([48, 10], 4);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
    maxZoom: 18,
  }).addTo(mapInstance);

  // London marker as the fixed origin point.
  L.circleMarker([51.5074, -0.1278], { radius: 6, color: "#2b5c7a", fillOpacity: 1 })
    .addTo(mapInstance)
    .bindPopup("<h4>London</h4>Home base");

  const bounds = [[51.5074, -0.1278]];
  suggestions.forEach((d) => {
    if (!d.coordinates) return;
    const marker = L.circleMarker([d.coordinates.lat, d.coordinates.lng], {
      radius: 7,
      color: "#c2452f",
      fillColor: "#c2452f",
      fillOpacity: 0.85,
    }).addTo(mapInstance);
    marker.bindPopup(
      `${d.image ? `<img class="popup-thumb" src="${d.image.imageUrl}" alt="" />` : ""}<h4>${d.name}, ${d.country}</h4>${d.flightTimeFromLondon} flight · ${d.budgetTier}<br/><a href="${d.links.flights.googleFlights}" target="_blank" rel="noopener">Check flights ↗</a>`
    );
    bounds.push([d.coordinates.lat, d.coordinates.lng]);
  });
  if (bounds.length > 1) mapInstance.fitBounds(bounds, { padding: [30, 30] });
}

// ---------- Visited Places ----------
const RATING_ICON = { great: "🟢", okay: "🟡", poor: "🔴" };

async function loadVisited() {
  const el = $("#visited-list");
  try {
    const { visitedPlaces } = await api("visited-places");
    if (visitedPlaces.length === 0) {
      el.innerHTML = `<p class="muted">Nothing logged yet — add a place above once you've been.</p>`;
      return;
    }
    el.innerHTML = visitedPlaces
      .map(
        (p) => `
        <div class="stamp-card">
          <div class="stamp-meta">${p.year || "visited"}${p.rating ? ` · <span class="rating-badge">${RATING_ICON[p.rating]}</span>` : ""}</div>
          <div class="stamp-name">${p.name}${p.country ? `, ${p.country}` : ""}</div>
          ${p.notes ? `<div class="stamp-notes">${p.notes}</div>` : ""}
          <button class="link" data-remove="${p.id}">remove</button>
        </div>`
      )
      .join("");
    $$("#visited-list [data-remove]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        await api(`visited-places?id=${encodeURIComponent(btn.dataset.remove)}`, { method: "DELETE" });
        await Promise.all([loadVisited(), loadSuggestions()]);
      });
    });
  } catch (err) {
    el.innerHTML = `<div class="error-banner">Couldn't load visited places: ${err.message}</div>`;
  }
}

let selectedRating = null;
$$("#rating-chips .chip").forEach((chip) => {
  chip.addEventListener("click", () => {
    const already = chip.classList.contains("selected");
    $$("#rating-chips .chip").forEach((c) => c.classList.remove("selected"));
    if (!already) {
      chip.classList.add("selected");
      selectedRating = chip.dataset.rating;
    } else {
      selectedRating = null;
    }
  });
});

$("#visited-add-btn").addEventListener("click", async () => {
  const name = $("#visited-name").value.trim();
  if (!name) return;
  const body = {
    name,
    country: $("#visited-country").value.trim(),
    year: $("#visited-year").value.trim(),
    notes: $("#visited-notes").value.trim(),
    rating: selectedRating,
  };
  await api("visited-places", { method: "POST", body: JSON.stringify(body) });
  $("#visited-name").value = "";
  $("#visited-country").value = "";
  $("#visited-year").value = "";
  $("#visited-notes").value = "";
  $$("#rating-chips .chip").forEach((c) => c.classList.remove("selected"));
  selectedRating = null;
  $("#extract-results").innerHTML = "";
  await Promise.all([loadVisited(), loadSuggestions()]);
});

$("#extract-btn").addEventListener("click", async () => {
  const btn = $("#extract-btn");
  const name = $("#visited-name").value.trim();
  const notes = $("#visited-notes").value.trim();
  const out = $("#extract-results");
  if (!name || !notes) {
    out.innerHTML = `<p class="muted">Fill in a place name and some notes first, then extract.</p>`;
    return;
  }
  btn.disabled = true;
  out.innerHTML = `<p class="muted">Reading your notes…</p>`;
  try {
    const { suggestions } = await api("extract-preferences", {
      method: "POST",
      body: JSON.stringify({ placeName: name, notes }),
    });
    if (suggestions.length === 0) {
      out.innerHTML = `<p class="muted">Nothing new to add — either nothing durable stood out, or it's already in your profile.</p>`;
      return;
    }
    out.innerHTML = suggestions
      .map(
        (s, i) => `
      <div class="suggestion-chip-row" id="sug-${i}">
        <div>
          <span class="sug-section">${s.sectionTitle}</span>
          ${s.text}
        </div>
        <div class="sug-actions">
          <button class="accept" data-accept="${i}">Add</button>
          <button class="reject" data-reject="${i}">Skip</button>
        </div>
      </div>`
      )
      .join("");
    $$("#extract-results [data-accept]").forEach((b) => {
      b.addEventListener("click", async () => {
        const s = suggestions[Number(b.dataset.accept)];
        await api("profile", { method: "POST", body: JSON.stringify({ action: "addPoint", sectionId: s.sectionId, text: s.text }) });
        $(`#sug-${b.dataset.accept}`).classList.add("resolved");
        $(`#sug-${b.dataset.accept}`).querySelector(".sug-actions").innerHTML = "Added ✓";
        await loadProfile();
      });
    });
    $$("#extract-results [data-reject]").forEach((b) => {
      b.addEventListener("click", () => {
        $(`#sug-${b.dataset.reject}`).classList.add("resolved");
        $(`#sug-${b.dataset.reject}`).querySelector(".sug-actions").innerHTML = "Skipped";
      });
    });
  } catch (err) {
    out.innerHTML = `<div class="error-banner">${err.message}</div>`;
  } finally {
    btn.disabled = false;
  }
});

// ---------- Plan with AI ----------
$("#plan-btn").addEventListener("click", async () => {
  const btn = $("#plan-btn");
  const out = $("#plan-output");
  const linksOut = $("#plan-links");
  const destinationId = $("#plan-destination").value;
  const checkin = $("#plan-checkin").value;
  const checkout = $("#plan-checkout").value;
  const extra = $("#plan-extra").value.trim();
  if (!destinationId) return;

  const dates = checkin && checkout ? `${checkin} to ${checkout}` : "your chosen dates";

  btn.disabled = true;
  btn.textContent = "Thinking…";
  out.innerHTML = "";
  linksOut.innerHTML = "";
  try {
    const [{ itinerary }, staysRes] = await Promise.all([
      api("plan-trip", { method: "POST", body: JSON.stringify({ destinationId, dates, extra }) }),
      api(`accommodations?destinationId=${encodeURIComponent(destinationId)}${checkin ? `&checkin=${checkin}` : ""}${checkout ? `&checkout=${checkout}` : ""}`).catch(() => null),
    ]);
    out.innerHTML = `<div class="itinerary-output">${itinerary.replace(/</g, "&lt;")}</div>`;
    if (staysRes) {
      linksOut.innerHTML = `<div class="card">
        <h3>Live search, same dates</h3>
        <div class="dest-actions">
          <a class="btn-link" href="${staysRes.links.flights.googleFlights}" target="_blank" rel="noopener">Google Flights ↗</a>
          <a class="btn-link" href="${staysRes.links.flights.skyscanner}" target="_blank" rel="noopener">Skyscanner ↗</a>
          <a class="btn-link" href="${staysRes.links.accommodation.booking}" target="_blank" rel="noopener">Booking.com ↗</a>
          <a class="btn-link" href="${staysRes.links.accommodation.airbnb}" target="_blank" rel="noopener">Airbnb ↗</a>
        </div>
      </div>`;
    }
  } catch (err) {
    out.innerHTML = `<div class="error-banner">${err.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Generate itinerary";
  }
});

// ---------- Profile ----------
async function loadProfile() {
  const el = $("#profile-content");
  try {
    const { profile } = await api("profile");
    el.innerHTML =
      `<p class="muted">${profile.travelers} · based in ${profile.home}</p>` +
      profile.sections
        .map(
          (s) => `
        <div class="card">
          <h3>${s.title}</h3>
          <ul class="profile-points">
            ${s.points
              .map(
                (p, i) => `
              <li>
                <span>${p}</span>
                <button class="remove-point" data-remove-point data-section="${s.id}" data-index="${i}">remove</button>
              </li>`
              )
              .join("")}
          </ul>
          <div class="add-point-row">
            <input type="text" placeholder="Add a preference…" data-add-point-input="${s.id}" />
            <button class="btn-link" data-add-point="${s.id}">Add</button>
          </div>
        </div>`
        )
        .join("");

    $$("#profile-content [data-remove-point]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        await api("profile", {
          method: "POST",
          body: JSON.stringify({ action: "removePoint", sectionId: btn.dataset.section, index: Number(btn.dataset.index) }),
        });
        await loadProfile();
      });
    });
    $$("#profile-content [data-add-point]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const input = $(`[data-add-point-input="${btn.dataset.addPoint}"]`);
        const text = input.value.trim();
        if (!text) return;
        await api("profile", {
          method: "POST",
          body: JSON.stringify({ action: "addPoint", sectionId: btn.dataset.addPoint, text }),
        });
        await loadProfile();
      });
    });
  } catch (err) {
    el.innerHTML = `<div class="error-banner">Couldn't load profile: ${err.message}</div>`;
  }
}

// ---------- Boot ----------
async function bootApp() {
  await Promise.all([loadRadar(), loadVisited(), loadProfile()]);
  await loadSuggestions(); // populates lastSuggestions, used by the map
  initMap(lastSuggestions);
}

bootApp();
